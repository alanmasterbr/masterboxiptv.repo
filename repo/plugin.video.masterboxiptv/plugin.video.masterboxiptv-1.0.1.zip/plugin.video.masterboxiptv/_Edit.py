import xbmcaddon
MainBase = 'http://www.masterboxfilmes.ml'
addon = xbmcaddon.Addon('plugin.video.masterboxiptv')